package cn.zwz.data.dao.mapper;

import cn.zwz.data.entity.Department;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author 郑为中
 * CSDN: Designer 小郑
 */
public interface DepartmentMapper extends BaseMapper<Department> {
}

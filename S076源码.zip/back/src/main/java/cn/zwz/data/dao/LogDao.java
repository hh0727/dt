package cn.zwz.data.dao;

import cn.zwz.basics.baseClass.ZwzBaseDao;
import cn.zwz.data.entity.Log;

/**
 * @author 郑为中
 * CSDN: Designer 小郑
 */
public interface LogDao extends ZwzBaseDao<Log,String> {

}

package cn.zwz.data.service;

import cn.zwz.data.entity.Permission;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * @author 郑为中
 * CSDN: Designer 小郑
 */
public interface IPermissionService extends IService<Permission> {
}

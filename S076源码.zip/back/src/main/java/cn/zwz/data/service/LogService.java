package cn.zwz.data.service;

import cn.zwz.basics.baseClass.ZwzBaseService;
import cn.zwz.data.entity.Log;

/**
 * @author 郑为中
 * CSDN: Designer 小郑
 */
public interface LogService extends ZwzBaseService<Log,String> {

}

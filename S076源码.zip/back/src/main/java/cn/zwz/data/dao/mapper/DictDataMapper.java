package cn.zwz.data.dao.mapper;

import cn.zwz.data.entity.DictData;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author 郑为中
 * CSDN: Designer 小郑
 */
public interface DictDataMapper extends BaseMapper<DictData> {
}

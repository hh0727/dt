package cn.zwz.data.service;

import cn.zwz.data.entity.Log;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @author 郑为中
 * CSDN: Designer 小郑
 */
public interface ILogService extends IService<Log> {

}
